package com.example.aulafragmentos

import androidx.fragment.app.Fragment

class FragmentoA:  Fragment(R.layout.fragmento_a) {
}