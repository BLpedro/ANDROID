package com.example.aulafragmentos

import androidx.fragment.app.Fragment

class FragmentoB:  Fragment(R.layout.fragmento_b) {
}